import { useState } from "react";
import { useDispatch } from "react-redux";
function AddArticle(){
    const [form,setForm] = useState({})
    const dispatch = useDispatch();
    const AddArti = (e) => {
        setForm({
            ...form,
            [e.target.id] : e.target.value,
        })
    };
    const add = (e) => {
        e.preventDefault();
        dispatch({
            type:'ADD_ARTICLE',
            payload: form
        })
        setForm({id:"",title:"",body:""})
    }
    return(
    <form onSubmit={add}>
        <label>id</label>
        <input type="text" id="id" onChange={AddArti}/>
        <label>title</label>
        <input type="text" id="title" onChange={AddArti}/>
        <label>body</label>
        <input type="text" id="body" onChange={AddArti}/>
        <button>Add article</button>
    </form>)
}
export default AddArticle;