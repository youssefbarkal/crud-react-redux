import { legacy_createStore } from 'redux';
const stateInitial = {
    Liste : [
      {id:1,title:'poste1',body:'Quisque cursus, metus vitae pharetera'},
      {id:2,title:'poste2',body:'Quisque cursus, metus vitae pharetera'}
    ]
}
const Reducer = (state=stateInitial,action) => {
    if(action.type === 'ADD_ARTICLE'){
        return {
            ...state,
            Liste : [...state.Liste,action.payload]
        }
    }
    return state;
}
const Store = legacy_createStore(Reducer)

export {Store,Reducer}