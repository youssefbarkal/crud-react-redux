import AddArticle from "./addArticle";
import Article from "./article";
const Articles = () => {
    return(
    <div>
        <AddArticle />
        <Article />
    </div>)
}
export default Articles;