import { useSelector } from "react-redux";
function Article(){
    const Data = useSelector(state => state.Liste)
    return(
        <div>
            {Data.map((article,index) => {
                return <div key={index}>
                    <h1>{article.title}</h1>
                    <p>{article.body}</p>
                </div>
            })}
        </div>
    )
}
export default Article;